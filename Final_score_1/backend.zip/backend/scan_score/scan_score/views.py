import os
from io import StringIO
import io
import json
import numpy as np
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.sites import requests
from django.http import HttpResponse, StreamingHttpResponse, HttpResponseForbidden
from django.shortcuts import render, redirect
import base64
import cv2
from PIL import Image
from django.core.files.base import ContentFile

import json
from .forms import DocumentForm, SignUpForm, CustomUserCreationForm, ImageUploadForm

# for rest api views
from django.contrib.auth import get_user_model
from rest_framework.generics import CreateAPIView
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework import status
from rest_framework.views import APIView
import cv2
from .serializers import CreateUserSerializer

from .utills import  main
from .model import Document, ExampleModel


# Create your views here.

def upload_pic(request):
    if request.method == 'POST':
        # if 'blob' in request.FILES:
        #     print("blob")
        img = request.POST['blob']
        # image_parts = explode(";base64,", $img);
        image_parts=img.split(";base64,")

        # image_type_aux = explode("image/", $image_parts[0]);
        image_type_aux=image_parts[0].split("image/")

        image_type = image_type_aux[1];

        # $image_base64 = base64_decode($image_parts[1]);

        image_base64 = base64.b64decode(image_parts[1])
        print(image_base64)



        with open('picture_out.jpg', 'wb') as f:
            f.write(image_base64)

        data = ContentFile(image_base64, name='temp.jpg')  # You can save this as file instance.
        m = ExampleModel()
        m.model_pic = data
        m.save()



        # print(image_parts[1])






        # form = DocumentForm(request.POST, request.FILES)
        # print(request.POST)

        # img_uri = request.POST['blob']
        # image_data = base64.b64decode(img_uri)
        # img = ContentFile(image_data, 'imagen1.png')

        # fh = open("imageToSave.jpg", "wb")
        # fh.write((img))
        # fh.close()




        # img = base64.b64encode(requests.get(img).content)

        # with open("img.png", 'wb') as f:
        #     f.write(img)

        # print(img+"bloob")

        #     document_file = request.FILES['blob']
        #     print("talha")

        # form = ImageUploadForm(request.POST, request.FILES)
        # print(form)
        # if form.is_valid():

        # m = ExampleModel()
        # m.model_pic = file
        # #     print(m)
        # m.save()
        return HttpResponse('image upload success')
    return HttpResponseForbidden('allowed only via POST')


def webcam(request):





        # if form.is_valid():
        #     form.save()
    #     img = request.POST.get['avatar']
    #     print(img)

        # print(img)



        # img = request.POST['blob']  # Getting the object from the post request
        # print(img)
        # img.encode()
        # print(img.encode())

        # with open('picture_out.png', 'wb') as f:
        #     f.write(img)

        # format, imgstr = img.split(';base64,')
        # ext = format.split('/')[-1]
        #
        # data = ContentFile(base64.b64decode(imgstr), name='temp.' + ext)
        # print (data)
        # data.save( "abc", ContentFile(data, save=True,)

        # with open("imageToSave.png", "wb") as fh:
        #     fh.write(base64
        #     .decodebytes(str(img)))

        # answer_obj = Document.objects.create(document=img)
        # answer_obj.document.save(img, request.FILES['avatar'])
        # answer_obj.save()

        # form = DocumentForm(request.POST, img)
        # if form.is_valid():
        #     form.save()
            # time.sleep(7)
        # return redirect('thanks')




    #
    #     form = DocumentForm(request.POST, request.FILES)
    #     if form.is_valid():
    #         form.save()
    #     #     # time.sleep(7)
    #         return redirect('thanks')
    #
    # else:
    #     form = DocumentForm()

    return  render(request, "webcamjs/demos/preview.html")
    # return  render(request, "add.html")



def save_image(requests):
    cam = cv2.VideoCapture(0)

    cv2.namedWindow("test")

    img_counter = 0

    while True:
        ret, frame = cam.read()
        cv2.imshow("test", frame)
        if not ret:
            break
        k = cv2.waitKey(1)

        if k % 256 == 27:
            # ESC pressed
            print("Escape hit, closing...")
            break
        elif k % 256 == 32:
            # SPACE pressed
            img_name = "opencv_frame_{}.png".format(img_counter)
            cv2.imwrite(img_name, frame)
            print("{} written!".format(img_name))
            img_counter += 1

    cam.release()

    cv2.destroyAllWindows()

    # return render(requests, 'webcam.html')



class CreateUserAPIView(CreateAPIView):
    serializer_class = CreateUserSerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        # We create a token than will be used for future auth
        token = Token.objects.create(user=serializer.instance)
        token_data = {"token": token.key}
        return Response(
            {**serializer.data, **token_data},
            status=status.HTTP_201_CREATED,
            headers=headers
        )


class LogoutUserAPIView(APIView):
    queryset = get_user_model().objects.all()

    def get(self, request, format=None):
        # simply delete the token to force a login
        request.user.auth_token.delete()
        return Response(status=status.HTTP_200_OK)


def signup(request):
    if request.method == 'POST':
        f = CustomUserCreationForm(request.POST)
        if f.is_valid():
            f.save()
            messages.success(request, 'Account created successfully')
            return redirect('signup')

    else:
        f = CustomUserCreationForm()

    return render(request, 'signup.html', {'form': f})


def home(requests):
    return render(requests, 'welcome.html')


@login_required
def thanks(requests):
    main()
    return render(requests, 'thank-you.html')


@login_required
def model_form_upload(request):

    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            # time.sleep(7)
            return redirect('select')

    else:
        form = DocumentForm()
    return render(request, 'fileupload.html', {'form': form})


@login_required
def select_test_type(request):
    return render(request, 'select-score.html')


@login_required
def index(request):
    # with open('/home/junaid/PycharmProjects/scan_score/media/document.json', 'r') as f:
    #     json_object = f.read()
    json_object = {
        "student_name": "Talha Mobin",
        "test_date": "2018-11-03",
        "test_form_no": "0001",
        "english": {
            "score": 32,
            "correct": 70,
            "incorrect": 5,
            "omitted": 0,
            "answers": {
                "q1": "B",
                "q2": "F",
                "q3": "C",
                "q4": "H",
                "q5": "A",
                "q6": "G",
                "q7": "D",
                "q8": "J",
                "q9": "B",
                "q10": "J",
                "q11": "C",
                "q12": "H",
                "q13": "D",
                "q14": "F",
                "q15": "A",
                "q16": "F",
                "q17": "D",
                "q18": "J",
                "q19": "B",
                "q20": "G",
                "q21": "A",
                "q22": "F",
                "q23": "D",
                "q24": "H",
                "q25": "B",
                "q26": "J",
                "q27": "D",
                "q28": "F",
                "q29": "C",
                "q30": "G",
                "q31": "B",
                "q32": "J",
                "q33": "A",
                "q34": "F",
                "q35": "A",
                "q36": "F",
                "q37": "C",
                "q38": "H",
                "q39": "D",
                "q40": "H",
                "q41": "C",
                "q42": "G",
                "q43": "B",
                "q44": "G",
                "q45": "A",
                "q46": "F",
                "q47": "D",
                "q48": "J",
                "q49": "B",
                "q50": "H",
                "q51": "D",
                "q52": "F",
                "q53": "C",
                "q54": "J",
                "q55": "A",
                "q56": "J",
                "q57": "B",
                "q58": "H",
                "q59": "D",
                "q60": "G",
                "q61": "A",
                "q62": "F",
                "q63": "B",
                "q64": "J",
                "q65": "A",
                "q66": "F",
                "q67": "C",
                "q68": "G",
                "q69": "C",
                "q70": "H",
                "q71": "A",
                "q72": "G",
                "q73": "D",
                "q74": "F",
                "q75": "C"
            }
        },
        "math": {
            "score": "32",
            "correct": "55",
            "incorrect": "5",
            "omitted": "0",
            "answers": {
                "q1": "E",
                "q2": "F",
                "q3": "C",
                "q4": "H",
                "q5": "B",
                "q6": "K",
                "q7": "D",
                "q8": "J",
                "q9": "B",
                "q10": "G",
                "q11": "E",
                "q12": "H",
                "q13": "E",
                "q14": "K",
                "q15": "A",
                "q16": "F",
                "q17": "D",
                "q18": "J",
                "q19": "E",
                "q20": "K",
                "q21": "C",
                "q22": "F",
                "q23": "D",
                "q24": "J",
                "q25": "E",
                "q26": "H",
                "q27": "A",
                "q28": "K",
                "q29": "C",
                "q30": "G",
                "q31": "B",
                "q32": "J",
                "q33": "A",
                "q34": "F",
                "q35": "E",
                "q36": "G",
                "q37": "C",
                "q38": "H",
                "q39": "D",
                "q40": "H",
                "q41": "C",
                "q42": "G",
                "q43": "E",
                "q44": "G",
                "q45": "D",
                "q46": "K",
                "q47": "B",
                "q48": "K",
                "q49": "B",
                "q50": "J",
                "q51": "D",
                "q52": "F",
                "q53": "C",
                "q54": "H",
                "q55": "A",
                "q56": "J",
                "q57": "C",
                "q58": "K",
                "q59": "B",
                "q60": "G",
            }
        },
        "reading": {
            "score": "32",
            "correct": "36",
            "incorrect": "4",
            "omitted": "0",
            "answers": {
                "q1": "B",
                "q2": "F",
                "q3": "C",
                "q4": "H",
                "q5": "A",
                "q6": "G",
                "q7": "D",
                "q8": "J",
                "q9": "B",
                "q10": "J",
                "q11": "C",
                "q12": "H",
                "q13": "D",
                "q14": "F",
                "q15": "A",
                "q16": "F",
                "q17": "D",
                "q18": "J",
                "q19": "B",
                "q20": "G",
                "q21": "A",
                "q22": "F",
                "q23": "D",
                "q24": "H",
                "q25": "B",
                "q26": "J",
                "q27": "D",
                "q28": "F",
                "q29": "C",
                "q30": "G",
                "q31": "B",
                "q32": "J",
                "q33": "A",
                "q34": "F",
                "q35": "A",
                "q36": "F",
                "q37": "C",
                "q38": "H",
                "q39": "D",
                "q40": "H"
            }
        },
        "science": {
            "score": "32",
            "correct": "36",
            "incorrect": "4",
            "omitted": "0",
            "answers": {
                "q1": "B",
                "q2": "F",
                "q3": "C",
                "q4": "H",
                "q5": "A",
                "q6": "G",
                "q7": "D",
                "q8": "J",
                "q9": "B",
                "q10": "J",
                "q11": "C",
                "q12": "H",
                "q13": "D",
                "q14": "F",
                "q15": "A",
                "q16": "F",
                "q17": "D",
                "q18": "J",
                "q19": "B",
                "q20": "G",
                "q21": "A",
                "q22": "F",
                "q23": "D",
                "q24": "H",
                "q25": "B",
                "q26": "J",
                "q27": "D",
                "q28": "F",
                "q29": "C",
                "q30": "G",
                "q31": "B",
                "q32": "J",
                "q33": "A",
                "q34": "F",
                "q35": "A",
                "q36": "F",
                "q37": "C",
                "q38": "H",
                "q39": "D",
                "q40": "H"
            }
        }
    }

    d = json.dumps(json_object)
    result = json.loads(d)

    # if request.method == 'GET':
    # {json_object: 'json_object'}
    return render(request, 'index.html', {'result': result})


@login_required
def logout(request):
    if request.user.is_authenticated:
        return render(request, 'registration/login.html')
