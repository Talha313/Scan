from django.apps import AppConfig


class ScanScoreConfig(AppConfig):
    name = 'scan_score'
