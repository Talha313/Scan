from django.conf.urls import url
from django.contrib.auth import views as auth_views
from scan_score import views as scan_score_views
from rest_framework.authtoken.views import obtain_auth_token
from .views import CreateUserAPIView, LogoutUserAPIView



urlpatterns = [
    url(r'^$', scan_score_views.home, name='home'),
    url(r'^$', scan_score_views.home, name='home'),
    url(r'^signup$', scan_score_views.signup, name='signup'),
    url(r'^select/$', scan_score_views.select_test_type, name='select'),
    url(r'^fileupload/', scan_score_views.model_form_upload, name='fileupload'),
    url(r'^thanks$', scan_score_views.thanks, name='thanks'),
    url(r'^index/', scan_score_views.index, name='index'),
    url(r'^upload_pic/', scan_score_views.upload_pic, name='upload_pic'),

    url(r'^webcam', scan_score_views.webcam, name='webcam'),

# url(regex=r'^persona/$', name='add_persona'),
#     url(r'^add$/', PersonaCreateView.as_view(), name='auth_user_create'),

    # url(regex=r'^save_image/(?P<cedula>\d+)/$',
    #     view=SaveImage.as_view(),
    #     name='salvar_imagen'
    #     ),

    # url(regex=r'^persona/$',
    #     view=PersonaCreateView.as_view(),
    #     name='add_persona'
    #     ),
    url(r'^camera', scan_score_views.save_image, name='add'),
    # for api

    url(r'^api/auth/login/$', obtain_auth_token, name='auth_user_login'),
    url(r'^api/auth/register/$', CreateUserAPIView.as_view(), name='auth_user_create'),
    url(r'^api/auth/logout/$', LogoutUserAPIView.as_view(), name='auth_user_logout')

]
